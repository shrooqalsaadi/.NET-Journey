﻿namespace ToDoList.Models
{
    public class ToDo
    {
        public int ID { get; set; }

        public string Name { get; set; }   
        
    }
}
