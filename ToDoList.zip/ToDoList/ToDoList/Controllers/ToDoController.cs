﻿using Microsoft.AspNetCore.Mvc;
using ToDoList.Data;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class ToDoController : Controller
    {

        private readonly ApplicationDBContext _db;
            public ToDoController(ApplicationDBContext db)
        {
            _db = db;   
        }
        public IActionResult Index()
        {
            var todoobj=_db.ToDos.ToList();
            return View(todoobj);
        }



        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(ToDo obj)
        {
            _db.ToDos.Add(obj);
            _db.SaveChanges();
            return RedirectToAction ("Index");
        }

        public IActionResult Update(int ID)
        {
            var data = _db.ToDos.FirstOrDefault(x => x.ID == ID);
            return View(data);
        }
        [HttpPost]
        public IActionResult Update(ToDo obj) 
        { 
            
            _db.ToDos.Update(obj);
            _db.SaveChanges();  
            return RedirectToAction("Index");   
        
        
        }
        public IActionResult Delete (int ID)
        {
            var data = _db.ToDos.FirstOrDefault(x => x.ID == ID);
            _db.ToDos.Remove(data);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }



    }
}
