﻿using Microsoft.EntityFrameworkCore;
using ToDoList.Models;

namespace ToDoList.Data
{

    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext>Options):base (Options) 
        {

        }

        public DbSet<ToDo> ToDos { set; get; }
    }
}
